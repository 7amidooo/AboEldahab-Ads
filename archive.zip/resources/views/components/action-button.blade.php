<a href="{{ $href }}" class="btn btn-sm btn-{{ $color }}">
    {!! $text !!}
</a>
