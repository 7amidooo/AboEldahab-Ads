
{{--@dd('SSS')--}}
@extends('admin.master')
@section('title', __('keywords.index'))

@section('content')
    <div class="container-fluid mb-4">
        <div class="row">
            <!-- Number of Users Card with Graph -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title text-muted">Total Users</h5>
                        <h3 class="display-4 mb-0">1,235</h3>
                        <span class="text-success">+15%</span>
                        <i class="fe fe-arrow-up text-success"></i>
                    </div>
                    <div class="card-footer p-2">
                        <canvas id="usersGraph" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Number of Members Card with Graph -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title text-muted">Total Members</h5>
                        <h3 class="display-4 mb-0">980</h3>
                        <span class="text-success">+10%</span>
                        <i class="fe fe-arrow-up text-success"></i>
                    </div>
                    <div class="card-footer p-2">
                        <canvas id="membersGraph" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- Number of Categories Card with Graph -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title text-muted">Categories</h5>
                        <h3 class="display-4 mb-0">45</h3>
                        <span class="text-info">Stable</span>
                        <i class="fe fe-minus text-info"></i>
                    </div>
                    <div class="card-footer p-2">
                        <canvas id="categoriesGraph" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Number of Ads Card with Graph -->
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title text-muted">Total Ads</h5>
                        <h3 class="display-4 mb-0">1,560</h3>
                        <span class="text-warning">+5%</span>
                        <i class="fe fe-arrow-up text-warning"></i>
                    </div>
                    <div class="card-footer p-2">
                        <canvas id="adsGraph" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection




<script>
    // Placeholder for graph data initialization
    window.addEventListener('DOMContentLoaded', (event) => {
        const ctxUsers = document.getElementById('usersGraph').getContext('2d');
        const ctxMembers = document.getElementById('membersGraph').getContext('2d');
        const ctxCategories = document.getElementById('categoriesGraph').getContext('2d');
        const ctxAds = document.getElementById('adsGraph').getContext('2d');

        // Graph configurations
        new Chart(ctxUsers, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Users Growth',
                    data: [1000, 1100, 1150, 1200, 1250, 1235],
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    tension: 0.3,
                    fill: true,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: true
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(200, 200, 200, 0.3)'
                        }
                    }
                }
            }
        });

        new Chart(ctxMembers, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Members Growth',
                    data: [900, 920, 940, 960, 980, 980],
                    borderColor: 'rgba(54, 162, 235, 1)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    tension: 0.3,
                    fill: true,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: true
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(200, 200, 200, 0.3)'
                        }
                    }
                }
            }
        });

        new Chart(ctxCategories, {
            type: 'bar',
            data: {
                labels: ['Stable', 'New', 'Old'],
                datasets: [{
                    label: 'Categories Distribution',
                    data: [45, 5, 3],
                    backgroundColor: ['rgba(153, 102, 255, 0.5)', 'rgba(255, 159, 64, 0.5)', 'rgba(255, 99, 132, 0.5)'],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    },
                    tooltip: {
                        enabled: true
                    }
                }
            }
        });

        new Chart(ctxAds, {
            type: 'bar',
            data: {
                labels: ['Active Ads', 'Expired Ads', 'Pending Ads'],
                datasets: [{
                    label: 'Ads Status',
                    data: [1200, 200, 160],
                    backgroundColor: ['rgba(255, 206, 86, 0.5)', 'rgba(75, 192, 192, 0.5)', 'rgba(255, 99, 132, 0.5)'],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    },
                    tooltip: {
                        enabled: true
                    }
                }
            }
        });
    });
</script>
