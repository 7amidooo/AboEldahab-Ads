<?php $__env->startSection('title', __('keywords.add_new_service')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h3 class="card-title mb-0"><?php echo e(__('keywords.sections')); ?></h3>
                <div class="card-actions">
                    <a href="#" class="btn btn-icon btn-outline-success" data-bs-toggle="modal" data-bs-target="#addSectionModal">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-plus" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <path d="M12 5l0 14" />
                            <path d="M5 12l14 0" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Add Section Modal -->
            <div class="modal fade" id="addSectionModal" tabindex="-1" aria-labelledby="addSectionModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title" id="addSectionModalLabel">Add New Section</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('admin.sections.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <!-- Title Field -->
                                <div class="mb-3">
                                    <label for="title" class="form-label fw-bold">Title</label>
                                    <input type="text" name="title" id="title" class="form-control" placeholder="Enter title">
                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'title']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                </div>

                                <!-- Custom File Upload Field with Preview -->
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Upload Image</label>
                                    <div class="d-flex align-items-center">
                                        <label class="btn btn-outline-success me-3" for="image_upload">
                                            <i class="bi bi-upload me-2"></i> Choose Image
                                        </label>
                                        <input type="file" name="image_upload" id="image_upload" class="d-none" accept="image/*" onchange="previewImage(event)" required>
                                    </div>
                                    <div class="mt-3">
                                        <img id="image_preview" src="https://via.placeholder.com/150" alt="Image Preview" class="img-thumbnail d-none" style="max-width: 100%; height: auto;">
                                    </div>
                                </div>

                                <!-- Submit Button -->
                                <div class="d-flex justify-content-end">
                                    <button type="submit" class="btn btn-success">Save Section</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table of Sections -->
            <div class="table-responsive">
                <table class="table table-bordered card-table table-vcenter text-nowrap datatable">
                    <thead class="thead-dark">
                    <tr>
                        <th class="text-center"><?php echo e(__('keywords.title')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.section_icon')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.number_of_categories')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($section->name); ?></td>
                            <td class="text-center">
                                <img src="/<?php echo e($section->icon); ?>" alt="<?php echo e($section->name); ?> icon" style="width: 30px; height: 30px;" />
                            </td>
                            <td class="text-center"><?php echo e(\App\Models\Category::where('section_id', $section->id)->count()); ?></td>
                            <td class="text-center">
                                <!-- Show Section Button -->
                                <a href="<?php echo e(route('admin.sections.show', $section->id)); ?>" class="btn btn-info btn-sm mr-2" title="<?php echo e(__('keywords.show')); ?>">
                                    <i class="fas fa-eye"></i>
                                </a>

                                <!-- Edit Section Button -->
                                <a href="#" class="btn btn-warning btn-sm mr-2" data-bs-toggle="modal" data-bs-target="#editSectionModal" title="Edit"
                                   data-id="<?php echo e($section->id); ?>" data-name="<?php echo e($section->name); ?>" data-icon="<?php echo e($section->icon); ?>"
                                   onclick="openEditSectionModal(this)">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <!-- Edit Section Modal -->
                                <div class="modal fade" id="editSectionModal" tabindex="-1" aria-labelledby="editSectionModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header bg-warning">
                                                <h5 class="modal-title" id="editSectionModalLabel">Edit Section</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form id="editSectionForm" action="<?php echo e(route('admin.sections.edit', $section->id)); ?>" method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>

                                                    <!-- Name Field -->
                                                    <div class="mb-3">
                                                        <label for="section_name" class="form-label fw-bold">Section Name</label>
                                                        <input type="text" name="name" id="section_name" class="form-control" required>
                                                    </div>

                                                    <!-- Icon Field -->
                                                    <div class="mb-3">
                                                        <label class="form-label fw-bold">Icon</label>
                                                        <div class="d-flex align-items-center">
                                                            <label class="btn btn-outline-success me-3" for="icon_upload_edit">
                                                                <i class="bi bi-upload me-2"></i> Choose Image
                                                            </label>
                                                            <input type="file" name="icon_upload" id="icon_upload_edit" class="d-none" accept="image/*">
                                                        </div>
                                                        <div class="mt-3">
                                                            <img id="icon_preview" src="https://via.placeholder.com/150" alt="Icon Preview" class="img-thumbnail d-none" style="max-width: 100%; height: auto;">
                                                        </div>
                                                    </div>

                                                    <!-- Save Button -->
                                                    <div class="d-flex justify-content-end">
                                                        <button type="submit" class="btn btn-warning">Save Changes</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Delete Section Button -->
                                <form action="<?php echo e(route('admin.sections.destroy', $section->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')" title="<?php echo e(__('keywords.delete')); ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function previewImage(event) {
        const preview = document.getElementById('image_preview');
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                preview.src = reader.result;
                preview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        }
    }
    function openEditSectionModal(button) {
        const sectionId = button.getAttribute('data-id');
        const sectionName = button.getAttribute('data-name');
        const sectionIcon = button.getAttribute('data-icon');

        // Set the form action URL dynamically
        const form = document.getElementById('editSectionForm');
        form.action = `/sections/edit/${sectionId}`;

        // Populate the form fields with the data
        document.getElementById('section_name').value = sectionName;
        document.getElementById('icon_preview').src = `/${sectionIcon}`;
        document.getElementById('icon_preview').classList.remove('d-none');

        // Show the modal
        new bootstrap.Modal(document.getElementById('editSectionModal')).show();
    }
</script>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/sections/create.blade.php ENDPATH**/ ?>