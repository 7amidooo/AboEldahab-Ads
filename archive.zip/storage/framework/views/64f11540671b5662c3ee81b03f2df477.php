<label for="<?php echo e($field); ?>"><?php echo e(__("keywords.$field")); ?></label>
<?php /**PATH C:\xampp\htdocs\talabat\resources\views/components/form-label.blade.php ENDPATH**/ ?>