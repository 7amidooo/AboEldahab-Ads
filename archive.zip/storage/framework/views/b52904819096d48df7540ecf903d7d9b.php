<?php $__env->startSection('title', __('keywords.show_member')); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.member_details')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <img src="<?php echo e(asset($member->icon)); ?>" class="img-fluid rounded-circle mb-3" style="max-width: 200px;" alt="<?php echo e($member->name); ?>">
                            <h4 class="mb-1"><?php echo e($member->name); ?></h4>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <strong><?php echo e(__('keywords.section')); ?>:</strong>
                                <p><?php echo e($section); ?></p>
                            </div>
                            <div class="col-6">
                                <strong><?php echo e(__('keywords.category')); ?>:</strong>
                                <p><?php echo e($category); ?></p>
                            </div>
                            <div class="col-12">
                                <strong><?php echo e(__('keywords.location')); ?>:</strong>
                                <p><?php echo e($member->location); ?></p>
                            </div>
                            <div class="col-12">
                                <strong><?php echo e(__('keywords.contact_info')); ?>:</strong>
                                <p>
                                    <i class="bi bi-phone"></i> <?php echo e($member->phone); ?><br>
                                    <i class="bi bi-whatsapp"></i> <?php echo e($member->whatsapp); ?><br>
                                    <i class="bi bi-facebook"></i> <?php echo e($member->facebook); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.member_cover')); ?></h5>
                    </div>
                    <div class="card-body">
                        <img src="<?php echo e(asset($member->cover)); ?>" class="img-fluid w-100" alt="<?php echo e($member->name); ?> Cover">
                    </div>
                </div>

                <div class="card shadow mt-4">
                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.member_ads')); ?></h5>
                        <a href="<?php echo e(route('admin.ads', ['member_id' => $member->id])); ?>" class="btn btn-light btn-sm">
                            <i class="bi bi-plus"></i> <?php echo e(__('keywords.add_ad')); ?>

                        </a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover mb-0">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('keywords.ad_title')); ?></th>
                                    <th class="text-end"><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($ad->title); ?></td>
                                        <td class="text-end">
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.ads.show', $ad->id)); ?>" class="btn btn-info btn-sm">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <form action="<?php echo e(route('admin.ads.destroy', $ad->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"
                                                            onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2" class="text-center py-3">
                                            <?php echo e(__('keywords.no_ads_found')); ?>

                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/members/show.blade.php ENDPATH**/ ?>