<?php $__env->startSection('title', __('keywords.categories')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title"><?php echo e(__('keywords.filter_categories')); ?></h2>

                <!-- Form to Filter Categories by Section -->
                <div class="card shadow">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.categories.filter')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- Dropdown to select a section -->
                            <div class="mt-4">
                                <label for="section_id" class="form-label"><?php echo e(__('keywords.sections')); ?></label>
                                <select class="form-control" name="section_id" id="section_id">
                                    <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>

                            <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                        </form>
                    </div>
                </div>

                <h2 class="h5 page-title" style="margin-top: 30px"><?php echo e(__('keywords.add_new_category')); ?></h2>
                <!-- Form to Add a New Category with Section Selected -->
                <div class="card shadow mt-4">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.categories.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- Dropdown to select section for the new category -->
                            <div class="mt-4">
                                <label for="new_section_id" class="form-label"><?php echo e(__('keywords.select_section')); ?></label>
                                <select class="form-control" name="section_id" id="new_section_id">
                                    <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>

                            <!-- Category Name Input -->
                            <div class="mt-4">
                                <label for="category_name" class="form-label"><?php echo e(__('keywords.category_name')); ?></label>
                                <input type="text" name="name" id="category_name" class="form-control" placeholder="<?php echo e(__('keywords.enter_category_name')); ?>" required>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>

                            <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('keywords.add_category')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                        </form>
                    </div>
                </div>

                <!-- Display All Categories with Show and Delete Options -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title"><?php echo e(__('keywords.all_categories')); ?></h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th><?php echo e(__('keywords.categories')); ?></th>
                                <th class="d-flex justify-content-end"><?php echo e(__('keywords.actions')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->name); ?></td>
                                    <td class="d-flex justify-content-end">
                                        <!-- Show Category Button -->
                                        <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>" class="btn btn-info btn-sm me-2" style="display:inline;margin-right:5px; width: 55px; height: 25px; text-align: center;">
                                            <?php echo e(__('keywords.show')); ?>

                                        </a>

                                        <!-- Delete Category Button -->
                                        <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')" style="display:inline; width: 55px; height: 25px; text-align: center;">
                                                <?php echo e(__('keywords.delete')); ?>

                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- End of all categories list -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>