<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <!-- Messages Table Card -->
                <div class="card shadow-lg mb-4">
                    <div class="card-header bg-primary text-white d-flex align-items-center">
                        <h5 class="card-title mb-0"><?php echo e(__('keywords.messages')); ?></h5>
                    </div>

                    <!-- Messages Table -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th scope="col" class="fw-bold"><?php echo e(__('keywords.sender')); ?></th>
                                    <th scope="col" class="fw-bold"><?php echo e(__('keywords.message')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="table-row">
                                        <!-- Sender Name with Initial Icon -->
                                        <td class="d-flex align-items-center">
                                            <span class="fw-bold"><?php echo e($message->name); ?></span>
                                        </td>

                                        <!-- Full Message Content -->
                                        <td class="text-muted">
                                            <?php echo e($message->message); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-center mt-4">
                        <div class="pagination pagination-sm">
                            <?php echo e($messages->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/messages/index.blade.php ENDPATH**/ ?>