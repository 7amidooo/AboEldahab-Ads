<?php
    $locale = LaravelLocalization::getCurrentLocale() == 'ar' ? 'en' : 'ar';
?>
<a class="nav-link text-muted my-2" href="<?php echo e(LaravelLocalization::getLocalizedURL($locale)); ?>" id="langSwitcher">
    <?php echo e(strtoupper($locale)); ?>

</a>
<?php /**PATH /home/msarweb-check/htdocs/check.msarweb.net/resources/views/admin/partials/language.blade.php ENDPATH**/ ?>