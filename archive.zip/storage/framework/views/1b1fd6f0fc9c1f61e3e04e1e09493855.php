<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
<h1>Your OTP Code is: <?php echo e($otp); ?></h1>
<p>Please use this code to verify your email address.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\talabat\resources\views/mail/otp/content.blade.php ENDPATH**/ ?>