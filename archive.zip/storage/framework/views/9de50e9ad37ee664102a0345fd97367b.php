<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title mb-4"><?php echo e(__('keywords.rating')); ?></h2>

                <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 shadow-sm">
                        <div class="card-header d-flex justify-content-between align-items-center bg-light py-3">
                            <span class="fw-bold text-dark"><?php echo e(__('keywords.reviewer')); ?>: <?php echo e($rating->user->name ?? __('keywords.anonymous')); ?></span>
                            <small class="text-muted"><?php echo e($rating->created_at->format('d M Y, H:i')); ?></small>
                        </div>
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <span class="mr-2 fw-bold"><?php echo e(__('keywords.rating')); ?>:</span>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?php echo e($i <= $rating->rating ? ' text-warning' : ' text-secondary'); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="text-dark mb-0"><strong class="mr-1"><?php echo e(__('keywords.review')); ?>:</strong> <?php echo e($rating->review); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                                       <?php echo e($ratings->links('pagination::bootstrap-4')); ?>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/rating/index.blade.php ENDPATH**/ ?>