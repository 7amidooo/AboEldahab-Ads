<?php $__env->startSection('title', __('keywords.update_contact_info')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title"><?php echo e(__('keywords.update_contact_info')); ?></h2>

                <!-- Contact Information Update Form -->
                <div class="card shadow mt-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><?php echo e(__('keywords.edit_contact_info')); ?></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.setting.update')); ?>" method="post" class="row g-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Phone Number Field -->
                            <div class="col-md-6">
                                <label for="phone" class="form-label fw-bold"><?php echo e(__('keywords.phone')); ?></label>
                                <input type="text" name="phone" id="phone" class="form-control" placeholder="<?php echo e(__('keywords.enter_phone')); ?>" value="<?php echo e(old('phone', \App\Models\Setting::find(1)->phone)); ?>" required>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'phone']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>

                            <!-- Email Field -->
                            <div class="col-md-6">
                                <label for="email" class="form-label fw-bold"><?php echo e(__('keywords.email')); ?></label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e(__('keywords.enter_email')); ?>" value="<?php echo e(old('email', \App\Models\Setting::find(1)->email)); ?>" required>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'email']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>

                            <!-- Update Button -->
                            <div class="col-12 d-flex justify-content-end mt-2">
                                <button type="submit" class="btn btn-success"><?php echo e(__('keywords.update')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/settings/create.blade.php ENDPATH**/ ?>