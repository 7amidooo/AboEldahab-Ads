<?php $__env->startSection('title', __('keywords.members')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title"><?php echo e(__('keywords.manage_users')); ?></h2>

                <!-- Search Bar -->
                <div class="mb-3">
                    <input type="text" id="searchInput" class="form-control" placeholder="<?php echo e(__('keywords.search_placeholder')); ?>" onkeyup="searchUsers()">
                    <ul id="memberSuggestions" class="list-group mt-2"></ul> <!-- Suggestions will appear here -->
                </div>

                <div class="card mt-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h3 class="card-title mb-0"><?php echo e(__('keywords.members')); ?></h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered card-table table-vcenter text-nowrap">
                                <thead class="thead-dark">
                                <tr>
                                    <th class="text-center"><?php echo e(__('keywords.name')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.email')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.phone')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.status')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($user->name); ?></td>
                                        <td class="text-center"><?php echo e($user->email); ?></td>
                                        <td class="text-center"><?php echo e($user->phone); ?></td>
                                        <td class="text-center"><?php echo e($user->is_verified ? 'active' : 'inactive'); ?></td>
                                        <td class="text-center">
                                            <!-- Edit Button -->
                                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editUserModal-<?php echo e($user->id); ?>">
                                                <?php echo e(__('keywords.edit')); ?>

                                            </button>

                                            <!-- Delete Form -->
                                            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')">
                                                    <?php echo e(__('keywords.delete')); ?>

                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Edit User Modal -->
                                    <div class="modal fade" id="editUserModal-<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="editUserModalLabel-<?php echo e($user->id); ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header bg-warning text-white">
                                                    <h5 class="modal-title" id="editUserModalLabel-<?php echo e($user->id); ?>"><?php echo e(__('keywords.edit_member')); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo e(__('keywords.close')); ?>"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>

                                                        <div class="mb-3">
                                                            <label for="name-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.name')); ?></label>
                                                            <input type="text" name="name" id="name-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->name); ?>" required>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="email-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.email')); ?></label>
                                                            <input type="email" name="email" id="email-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->email); ?>" required>
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="phone-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.phone')); ?></label>
                                                            <input type="text" name="phone" id="phone-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->phone); ?>">
                                                        </div>

                                                        <div class="mb-3">
                                                            <label for="status-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.status')); ?></label>
                                                            <select name="status" id="status-<?php echo e($user->id); ?>" class="form-control">
                                                                <option value="1" <?php echo e($user->status ? 'selected' : ''); ?>><?php echo e('active'); ?></option>
                                                                <option value="0" <?php echo e(!$user->status ? 'selected' : ''); ?>><?php echo e('inactive'); ?></option>
                                                            </select>
                                                        </div>

                                                        <div class="d-flex justify-content-end">
                                                            <button type="submit" class="btn btn-warning"><?php echo e(__('keywords.save_changes')); ?></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Edit User Modal -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <!-- Bootstrap Pagination -->
                            <?php if($users->hasPages()): ?>
                                <nav>
                                    <ul class="pagination justify-content-center">
                                        
                                        <?php if($users->onFirstPage()): ?>
                                            <li class="page-item disabled">
                                                <span class="page-link">&laquo;</span>
                                            </li>
                                        <?php else: ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev">&laquo;</a>
                                            </li>
                                        <?php endif; ?>

                                        
                                        <?php $__currentLoopData = $users->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php if(is_string($element)): ?>
                                                <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
                                            <?php endif; ?>

                                            
                                            <?php if(is_array($element)): ?>
                                                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($page == $users->currentPage()): ?>
                                                        <li class="page-item active">
                                                            <span class="page-link"><?php echo e($page); ?></span>
                                                        </li>
                                                    <?php else: ?>
                                                        <li class="page-item">
                                                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <?php if($users->hasMorePages()): ?>
                                            <li class="page-item">
                                                <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next">&raquo;</a>
                                            </li>
                                        <?php else: ?>
                                            <li class="page-item disabled">
                                                <span class="page-link">&raquo;</span>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function searchUsers() {
        const query = document.getElementById('searchInput').value;
        const tableBody = document.querySelector('tbody');

        if (query.length > 0) {
            fetch(`/admin/users/search?query=${query}`)
                .then(response => response.json())
                .then(data => {
                    tableBody.innerHTML = data.html; // Replace table body content
                })
                .catch(error => console.error('Error fetching users:', error));
        } else {
            // Reload the full user list if the query is empty
            fetch(`/admin/users`)
                .then(response => response.json())
                .then(data => {
                    tableBody.innerHTML = data.html; // Reset table content
                })
                .catch(error => console.error('Error fetching users:', error));
        }
    }


    function selectUser(userId) {
        alert(`User ID: ${userId} selected!`); // Example action on user selection
        // You can implement additional functionality here
    }
</script>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/users/create.blade.php ENDPATH**/ ?>