<?php $__env->startSection('title', __('keywords.members')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title"><?php echo e(__('keywords.filter_members')); ?></h2>

                <!-- Filter Members Modal Trigger -->
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#filterMembersModal">
                        <i class="fas fa-filter"></i> <?php echo e(__('keywords.filter_members')); ?>

                    </button>
                </div>

                <!-- Filter Members Modal -->
                <div class="modal fade" id="filterMembersModal" tabindex="-1" aria-labelledby="filterMembersModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title" id="filterMembersModalLabel"><?php echo e(__('keywords.filter_members')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.members.filter')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <!-- Section Dropdown -->
                                    <div class="mb-3">
                                        <label for="filter_section_id" class="form-label"><?php echo e(__('keywords.select_section')); ?></label>
                                        <select class="form-control" name="section_id" id="filter_section_id" required>
                                            <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                    </div>

                                    <!-- Category Dropdown -->
                                    <div class="mb-3">
                                        <label for="filter_category_id" class="form-label"><?php echo e(__('keywords.select_category')); ?></label>
                                        <select class="form-control" name="category_id" id="filter_category_id" required>
                                            <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                            <!-- Categories populated via JavaScript -->
                                        </select>
                                        <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.filter')); ?></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Add Member Modal Trigger -->
                <div class="card shadow mt-4">
                    <!-- Add Member Modal -->
                    <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header bg-success text-white">
                                    <h5 class="modal-title" id="addMemberModalLabel"><?php echo e(__('keywords.add_new_member')); ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('admin.members.store')); ?>" method="post" enctype="multipart/form-data" class="row g-3">
                                        <?php echo csrf_field(); ?>

                                        <!-- Section and Category Selection -->
                                        <div class="col-md-6">
                                            <label for="section_id" class="form-label fw-bold"><?php echo e(__('keywords.select_section')); ?></label>
                                            <select class="form-control" name="section_id" id="section_id" required>
                                                <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="category_id" class="form-label fw-bold"><?php echo e(__('keywords.select_category')); ?></label>
                                            <select class="form-control" name="category_id" id="category_id_2" required>
                                                <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                                <!-- Categories populated via JavaScript -->
                                            </select>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <!-- Member Details -->
                                        <div class="col-md-6">
                                            <label for="member_name" class="form-label fw-bold"><?php echo e(__('keywords.member_name')); ?></label>
                                            <input type="text" name="name" id="member_name" class="form-control" placeholder="<?php echo e(__('keywords.enter_member_name')); ?>" required>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="location" class="form-label fw-bold"><?php echo e(__('keywords.member_location')); ?></label>
                                            <input type="text" name="location" id="location" class="form-control" placeholder="<?php echo e(__('keywords.enter_location')); ?>" required>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'location']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'location']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="phone" class="form-label fw-bold"><?php echo e(__('keywords.member_phone')); ?></label>
                                            <input type="text" name="phone" id="phone" class="form-control" placeholder="<?php echo e(__('keywords.enter_phone')); ?>" required>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'phone']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-6">
                                            <label for="whatsapp" class="form-label fw-bold"><?php echo e(__('keywords.member_whatsapp')); ?></label>
                                            <input type="text" name="whatsapp" id="whatsapp" class="form-control" placeholder="<?php echo e(__('keywords.enter_whatsapp')); ?>" required>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'whatsapp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'whatsapp']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <div class="col-md-12">
                                            <label for="facebook" class="form-label fw-bold"><?php echo e(__('keywords.member_facebook')); ?></label>
                                            <input type="text" name="facebook" id="facebook" class="form-control" placeholder="<?php echo e(__('keywords.enter_facebook')); ?>" required>
                                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'facebook']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'facebook']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                        </div>

                                        <!-- Logo Upload Field with Preview -->
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold"><?php echo e(__('keywords.upload_logo')); ?></label>
                                            <div class="d-flex align-items-center">
                                                <label class="btn btn-outline-success me-3" for="logo_upload">
                                                    <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_logo')); ?>

                                                </label>
                                                <input type="file" name="logo" id="logo_upload" class="d-none" accept="image/*" onchange="previewImage(event, 'logo_preview')" required>
                                            </div>
                                            <div class="mt-3">
                                                <img id="logo_preview" src="https://via.placeholder.com/150" alt="Logo Preview" class="img-thumbnail d-none" style="max-width: 100%; height: auto;">
                                            </div>
                                        </div>

                                        <!-- Cover Upload Field with Preview -->
                                        <div class="col-md-6">
                                            <label class="form-label fw-bold"><?php echo e(__('keywords.upload_cover')); ?></label>
                                            <div class="d-flex align-items-center">
                                                <label class="btn btn-outline-success me-3" for="cover_upload">
                                                    <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_cover')); ?>

                                                </label>
                                                <input type="file" name="cover" id="cover_upload" class="d-none" accept="image/*" onchange="previewImage(event, 'cover_preview')" required>
                                            </div>
                                            <div class="mt-3">
                                                <img id="cover_preview" src="https://via.placeholder.com/150" alt="Cover Preview" class="img-thumbnail d-none" style="max-width: 100%; height: auto;">
                                            </div>
                                        </div>

                                        <!-- Submit Button -->
                                        <div class="col-12 d-flex justify-content-end">
                                            <button type="submit" class="btn btn-success"><?php echo e(__('keywords.add_member')); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Display All Members -->
                <div class="card mt-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h3 class="card-title mb-0"><?php echo e(__('keywords.members')); ?></h3>
                        <div class="card-actions">
                            <a href="#" class="btn btn-icon btn-outline-success" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-plus" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                    <path d="M12 5l0 14" />
                                    <path d="M5 12l14 0" />
                                </svg>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered card-table table-vcenter text-nowrap datatable" style="font-size: 12px;">
                                <thead class="thead-dark">
                                <tr>
                                    <th class="text-center"><?php echo e(__('keywords.member_name')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.member_logo')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.member_category')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.member_section')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($member->name); ?></td>
                                        <td class="text-center"><img src="<?php echo e("/".$member->icon); ?>" style="width: 50px; height: 40px"></td>
                                        <?php
                                            $x =\App\Models\category::find($member->category_id)
                                        ?>
                                        <td class="text-center"><?php echo e($x->name); ?></td>
                                        <td class="text-center"><?php echo e(\App\Models\section::find($x->section_id)->name); ?></td>
                                        <td class="text-center">
                                            <!-- Show Member Button -->
                                            <a href="<?php echo e(route('admin.members.show', $member->id)); ?>" class="btn btn-info btn-sm me-2" title="<?php echo e(__('keywords.show')); ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <!-- Edit Member Button -->
                                            <a href="#" class="btn btn-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#editMemberModal-<?php echo e($member->id); ?>" title="<?php echo e(__('keywords.edit')); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <!-- Edit Member Modal -->
                                            <div class="modal fade" id="editMemberModal-<?php echo e($member->id); ?>" tabindex="-1" aria-labelledby="editMemberModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-warning text-white">
                                                            <h5 class="modal-title" id="editMemberModalLabel"><?php echo e(__('keywords.edit_member')); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('admin.members.update', $member->id)); ?>" method="post" enctype="multipart/form-data" class="row g-3">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>

                                                                <!-- Section and Category Selection -->
 <div class="col-md-6">
                                                                    <label for="section_id_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_section')); ?></label>
                                                                    <select class="form-control section-dropdown" name="section_id" id="section_id_edit_<?php echo e($member->id); ?>" data-member-id="<?php echo e($member->id); ?>" required>
                                                                        <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($section->id); ?>" <?php echo e($member->category->section_id == $section->id ? 'selected' : ''); ?>>
                                                                                <?php echo e($section->name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                              <div class="col-md-6">
    <label for="category_id_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_category')); ?></label>
    <select class="form-control" name="category_id" id="category_id_edit_<?php echo e($member->id); ?>" required>
        <option value=""><?php echo e(__('keywords.select_category')); ?></option>
        <?php $__currentLoopData = \App\Models\Category::where('section_id', $member->category->section_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php echo e($member->category_id == $category->id ? 'selected' : ''); ?>>
                <?php echo e($category->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
</div>


                                                                <!-- Member Details -->
                                                                <div class="col-md-6">
                                                                    <label for="member_name_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.member_name')); ?></label>
                                                                    <input type="text" name="name" id="member_name_edit_<?php echo e($member->id); ?>" class="form-control" value="<?php echo e($member->name); ?>" placeholder="<?php echo e(__('keywords.enter_member_name')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="location_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.member_location')); ?></label>
                                                                    <input type="text" name="location" id="location_edit_<?php echo e($member->id); ?>" class="form-control" value="<?php echo e($member->location); ?>" placeholder="<?php echo e(__('keywords.enter_location')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'location']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'location']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="phone_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.member_phone')); ?></label>
                                                                    <input type="text" name="phone" id="phone_edit_<?php echo e($member->id); ?>" class="form-control" value="<?php echo e($member->phone); ?>" placeholder="<?php echo e(__('keywords.enter_phone')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'phone']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="whatsapp_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.member_whatsapp')); ?></label>
                                                                    <input type="text" name="whatsapp" id="whatsapp_edit_<?php echo e($member->id); ?>" class="form-control" value="<?php echo e($member->whatsapp); ?>" placeholder="<?php echo e(__('keywords.enter_whatsapp')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'whatsapp']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'whatsapp']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-12">
                                                                    <label for="facebook_edit_<?php echo e($member->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.member_facebook')); ?></label>
                                                                    <input type="text" name="facebook" id="facebook_edit_<?php echo e($member->id); ?>" class="form-control" value="<?php echo e($member->facebook); ?>" placeholder="<?php echo e(__('keywords.enter_facebook')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'facebook']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'facebook']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <!-- Logo Upload Field with Preview -->
                                                                <div class="col-md-6">
                                                                    <label class="form-label fw-bold"><?php echo e(__('keywords.upload_logo')); ?></label>
                                                                    <div class="d-flex align-items-center">
                                                                        <label class="btn btn-outline-warning me-3" for="logo_upload_edit_<?php echo e($member->id); ?>">
                                                                            <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_logo')); ?>

                                                                        </label>
                                                                        <input type="file" name="logo" id="logo_upload_edit_<?php echo e($member->id); ?>" class="d-none" accept="image/*" onchange="previewImage(event, 'logo_preview_edit_<?php echo e($member->id); ?>')">
                                                                    </div>
                                                                    <div class="mt-3">
                                                                        <img id="logo_preview_edit_<?php echo e($member->id); ?>" src="<?php echo e($member->icon ? asset($member->icon) : 'https://via.placeholder.com/150'); ?>"
                                                                             alt="Logo Preview" class="img-thumbnail" style="max-width: 100%; height: auto;">
                                                                    </div>
                                                                </div>

                                                                <!-- Cover Upload Field with Preview -->
                                                                <div class="col-md-6">
                                                                    <label class="form-label fw-bold"><?php echo e(__('keywords.upload_cover')); ?></label>
                                                                    <div class="d-flex align-items-center">
                                                                        <label class="btn btn-outline-warning me-3" for="cover_upload_edit_<?php echo e($member->id); ?>">
                                                                            <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_cover')); ?>

                                                                        </label>
                                                                        <input type="file" name="cover" id="cover_upload_edit_<?php echo e($member->id); ?>" class="d-none" accept="image/*" onchange="previewImage(event, 'cover_preview_edit_<?php echo e($member->id); ?>')">
                                                                    </div>
                                                                    <div class="mt-3">
                                                                        <img id="cover_preview_edit_<?php echo e($member->id); ?>" src="<?php echo e($member->cover ? asset($member->cover) : 'https://via.placeholder.com/150'); ?>"
                                                                             alt="Cover Preview" class="img-thumbnail" style="max-width: 100%; height: auto;">
                                                                    </div>
                                                                </div>

                                                                <!-- Submit Button -->
                                                                <div class="col-12 d-flex justify-content-end">
                                                                    <button type="submit" class="btn btn-warning"><?php echo e(__('keywords.save_changes')); ?></button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Delete Member Button -->
                                            <form action="<?php echo e(route('admin.members.destroy', $member->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')" title="<?php echo e(__('keywords.delete')); ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- End of Members List -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function previewImage(event, previewId) {
        const preview = document.getElementById(previewId);
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                preview.src = reader.result;
                preview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Function to setup category dropdowns
        function setupCategoryDropdown(sectionDropdown, categoryDropdown) {
            sectionDropdown.addEventListener('change', function () {
                const sectionId = this.value;

                // Clear existing options
                categoryDropdown.innerHTML = '<option value=""><?php echo e(__('keywords.select_category')); ?></option>';

                if (sectionId) {
                    fetch(`/categories/${sectionId}`)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json();
                        })
                        .then(data => {
                            data.forEach(category => {
                                const option = document.createElement('option');
                                option.value = category.id;
                                option.textContent = category.name;
                                categoryDropdown.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Error fetching categories:', error));
                }
            });
        }

        // Setup for main dropdowns
        const mainSectionDropdown = document.getElementById('section_id');
        const mainCategoryDropdown = document.getElementById('category_id_2');
        if (mainSectionDropdown && mainCategoryDropdown) {
            setupCategoryDropdown(mainSectionDropdown, mainCategoryDropdown);
        }

        // Setup for filter dropdowns
        const filterSectionDropdown = document.getElementById('filter_section_id');
        const filterCategoryDropdown = document.getElementById('filter_category_id');
        if (filterSectionDropdown && filterCategoryDropdown) {
            setupCategoryDropdown(filterSectionDropdown, filterCategoryDropdown);
        }

        // Setup for edit member modals
        document.querySelectorAll('[id^="section_id_edit_"]').forEach(sectionDropdown => {
            const memberId = sectionDropdown.id.replace('section_id_edit_', '');
            const categoryDropdown = document.getElementById(`category_id_edit_${memberId}`);

            if (categoryDropdown) {
                setupCategoryDropdown(sectionDropdown, categoryDropdown);
            }
        });
    });
</script>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/members/create.blade.php ENDPATH**/ ?>