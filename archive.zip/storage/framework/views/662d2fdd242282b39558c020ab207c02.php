<?php $__env->startSection('title', __('keywords.show')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">


                <div class="card shadow">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="title"><?php echo e(__('keywords.category_name')); ?></label>
                                <p class="form-control"><?php echo e($category->name); ?></p>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th><?php echo e(__('keywords.members_name')); ?></th>
                                    <th class="d-flex justify-content-end" ><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($member->name); ?></td>
                                        <td class="d-flex justify-content-end">
                                            <!-- Show member Button -->
                                            <a href="<?php echo e(route('admin.members.show',$member->id)); ?>" class="btn btn-info btn-sm me-2">
                                                <?php echo e(__('keywords.show')); ?>

                                            </a>

                                            <!-- Delete member Button -->
                                            <form action="<?php echo e(route('admin.categories.destroy',$member->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                        style="margin-left: 10px;"
                                                        onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')">
                                                    <?php echo e(__('keywords.delete')); ?>

                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\talabat\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>