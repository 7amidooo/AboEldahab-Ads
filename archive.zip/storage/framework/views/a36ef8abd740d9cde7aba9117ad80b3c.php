<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Contact Message</title>
</head>
<body>
<h2>New Contact Message</h2>
<p><strong>Username:</strong> <?php echo e($data['name']); ?></p>
<p><strong>Phone:</strong> <?php echo e($data['phone']); ?></p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Message:</strong></p>
<p><?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/mail/message/message.blade.php ENDPATH**/ ?>