<?php $__env->startSection('title', __('keywords.show_category')); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-12 col-xl-10">
            <!-- Return Back Button -->
            <a href="<?php echo e(route('admin.categories')); ?>" class="btn btn-outline-secondary mb-4">
                <i class="fas fa-arrow-left me-2"></i><?php echo e(__('keywords.return_back')); ?>

            </a>

            <!-- Category Details Card -->
            <div class="card shadow-sm rounded-3 mb-4">
                <div class="card-header bg-light py-3">
                    <h5 class="mb-0 text-primary"><?php echo e(__('keywords.category_details')); ?></h5>
                </div>
                
                <div class="card-body">
                    <div class="row g-4">
                        <!-- Category Name -->
                        <div class="col-md-6">
                            <div class="p-4 bg-light rounded-3">
                                <label class="text-muted small text-uppercase"><?php echo e(__('keywords.category_name')); ?></label>
                                <h4 class="mb-0 mt-1"><?php echo e($category->name); ?></h4>
                            </div>
                        </div>

                        <!-- Section Name -->
                        <div class="col-md-6">
                            <div class="p-4 bg-light rounded-3">
                                <label class="text-muted small text-uppercase"><?php echo e(__('keywords.section')); ?></label>
                                <h4 class="mb-0 mt-1"><?php echo e(\App\Models\section::find($category->section_id)->name); ?></h4>
                            </div>
                        </div>

                        <!-- Category Icon -->
                        <div class="col-md-6">
                            <div class="p-4 bg-light rounded-3 text-center">
                                <label class="text-muted small text-uppercase d-block mb-3"><?php echo e(__('keywords.icon')); ?></label>
                                <?php if($category->icon): ?>
                                    <img src="<?php echo e(asset($category->icon)); ?>" 
                                         alt="<?php echo e($category->name); ?>" 
                                         class="img-thumbnail shadow-sm"
                                         style="width: 120px; height: 120px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="text-muted">
                                        <i class="fas fa-image fa-3x mb-2"></i>
                                        <p class="mb-0"><?php echo e(__('keywords.no_icon_available')); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Members Card -->
            <div class="card shadow-sm rounded-3">
                <div class="card-header bg-light py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 text-primary"><?php echo e(__('keywords.members')); ?></h5>
                    <span class="badge bg-primary"><?php echo e($members->count()); ?> <?php echo e(__('keywords.total')); ?></span>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="px-4"><?php echo e(__('keywords.member_name')); ?></th>
                                    <th class="text-end px-4" width="150"><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="px-4 py-3"><?php echo e($member->name); ?></td>
                                        <td class="text-end px-4 py-3">
                                            <!-- Show Member Button -->
                                            <a href="<?php echo e(route('admin.members.show', $member->id)); ?>" 
                                               class="btn btn-sm btn-outline-primary me-2" 
                                               title="<?php echo e(__('keywords.show')); ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <!-- Delete Member Button -->
                                            <form action="<?php echo e(route('admin.members.destroy', $member->id)); ?>" 
                                                  method="POST" 
                                                  class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')"
                                                        title="<?php echo e(__('keywords.delete')); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2" class="text-center py-4 text-muted">
                                            <i class="fas fa-folder-open fa-2x mb-2"></i>
                                            <p class="mb-0"><?php echo e(__('keywords.no_members_found')); ?></p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/categories/show.blade.php ENDPATH**/ ?>