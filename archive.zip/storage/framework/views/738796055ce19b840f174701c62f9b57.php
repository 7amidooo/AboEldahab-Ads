<!DOCTYPE html>
<html>
<head>
    <title>OTP Verification</title>
</head>
<body>
<h1>Your OTP Code is: <?php echo e($otp); ?></h1>
<p>Please use this code to verify your email address.</p>
</body>
</html>
<?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/mail/otp/content.blade.php ENDPATH**/ ?>