<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td class="text-center"><?php echo e($user->name); ?></td>
        <td class="text-center"><?php echo e($user->email); ?></td>
        <td class="text-center"><?php echo e($user->phone); ?></td>
        <td class="text-center"><?php echo e($user->is_verified ? 'active' : 'inactive'); ?></td>
        <td class="text-center">
            <!-- Edit Button -->
            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editUserModal-<?php echo e($user->id); ?>">
                <?php echo e(__('keywords.edit')); ?>

            </button>

            <!-- Delete Form -->
            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')">
                    <?php echo e(__('keywords.delete')); ?>

                </button>
            </form>
        </td>
    </tr>
    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal-<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="editUserModalLabel-<?php echo e($user->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="editUserModalLabel-<?php echo e($user->id); ?>"><?php echo e(__('keywords.edit_member')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo e(__('keywords.close')); ?>"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="name-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.name')); ?></label>
                            <input type="text" name="name" id="name-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->name); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.email')); ?></label>
                            <input type="email" name="email" id="email-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->email); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="phone-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.phone')); ?></label>
                            <input type="text" name="phone" id="phone-<?php echo e($user->id); ?>" class="form-control" value="<?php echo e($user->phone); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="status-<?php echo e($user->id); ?>" class="form-label"><?php echo e(__('keywords.status')); ?></label>
                            <select name="status" id="status-<?php echo e($user->id); ?>" class="form-control">
                                <option value="1" <?php echo e($user->status ? 'selected' : ''); ?>><?php echo e('active'); ?></option>
                                <option value="0" <?php echo e(!$user->status ? 'selected' : ''); ?>><?php echo e('inactive'); ?></option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-warning"><?php echo e(__('keywords.save_changes')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Edit User Modal -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="5" class="text-center"><?php echo e(__('keywords.no_records_found')); ?></td>
    </tr>
<?php endif; ?>
<?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/users/partials/user_table.blade.php ENDPATH**/ ?>