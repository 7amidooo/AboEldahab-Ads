<?php $__env->startSection('title', __('keywords.categories')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <!-- Filter Categories Modal Trigger -->
        <div class="d-flex justify-content-end mb-3">
            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#filterCategoriesModal">
                <i class="fas fa-filter"></i> <?php echo e(__('keywords.filter_categories')); ?>

            </button>
        </div>

        <!-- Filter Categories Modal -->
        <div class="modal fade" id="filterCategoriesModal" tabindex="-1" aria-labelledby="filterCategoriesModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="filterCategoriesModalLabel"><?php echo e(__('keywords.filter_categories')); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('admin.categories.filter')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="section_id" class="form-label"><?php echo e(__('keywords.sections')); ?></label>
                                <select class="form-control" name="section_id" id="section_id" required>
                                    <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                            </div>
                            <div class="d-flex justify-content-end">
                                <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Category Modal Trigger -->
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h3 class="card-title mb-0"><?php echo e(__('keywords.categories')); ?></h3>
                <div class="card-actions">
                    <a href="#" class="btn btn-icon btn-outline-success" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
            </div>

            <!-- Add Category Modal -->
            <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title" id="addCategoryModalLabel"><?php echo e(__('keywords.add_new_category')); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('admin.categories.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="new_section_id" class="form-label"><?php echo e(__('keywords.select_section')); ?></label>
                                    <select class="form-control" name="section_id" id="new_section_id" required>
                                        <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label for="category_name" class="form-label"><?php echo e(__('keywords.category_name')); ?></label>
                                    <input type="text" name="name" id="category_name" class="form-control" required>
                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'name']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(__('keywords.upload_icon')); ?></label>
                                    <div class="d-flex align-items-center">
                                        <label class="btn btn-outline-success me-3" for="icon_upload">
                                            <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_icon')); ?>

                                        </label>
                                        <input type="file" name="icon" id="icon_upload" class="d-none" accept="image/*" onchange="previewNewIcon(event)" required>
                                    </div>
                                    <div class="mt-3">
                                        <img id="icon_preview_new" src="https://via.placeholder.com/150" alt="Icon Preview" class="img-thumbnail d-none" style="width: 50px; height: 50px;" required>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end">
                                    <?php if (isset($component)) { $__componentOriginal13113c9f32f6116c43cb9fbecee94495 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13113c9f32f6116c43cb9fbecee94495 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('keywords.add_category')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $attributes = $__attributesOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__attributesOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13113c9f32f6116c43cb9fbecee94495)): ?>
<?php $component = $__componentOriginal13113c9f32f6116c43cb9fbecee94495; ?>
<?php unset($__componentOriginal13113c9f32f6116c43cb9fbecee94495); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Table of Categories -->
            <div class="table-responsive">
                <table class="table table-bordered card-table table-vcenter text-nowrap datatable">
                    <thead class="thead-dark">
                    <tr>
                        <th class="text-center"><?php echo e(__('keywords.name')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.icon')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.section')); ?></th>
                        <th class="text-center"><?php echo e(__('keywords.actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($category->name); ?></td>
                            <td class="text-center"><img src="<?php echo e('/' . $category->icon); ?>" height="40px" width="40px"></td>
                            <td class="text-center"><?php echo e(\App\Models\Section::where('id', $category->section_id)->first()->name); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>" class="btn btn-info btn-sm mr-2">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="#" class="btn btn-warning btn-sm mr-2" data-bs-toggle="modal" data-bs-target="#editCategoryModal"
                                   data-id="<?php echo e($category->id); ?>" data-name="<?php echo e($category->name); ?>" data-section-id="<?php echo e($category->section_id); ?>"
                                   data-icon="<?php echo e('/' . $category->icon); ?>" onclick="openEditCategoryModal(this)">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-white">
                    <h5 class="modal-title" id="editCategoryModalLabel"><?php echo e(__('keywords.edit_category')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editCategoryForm" action="#" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="category_name_edit" class="form-label"><?php echo e(__('keywords.category_name')); ?></label>
                            <input type="text" name="name" id="category_name_edit" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="section_id_edit" class="form-label"><?php echo e(__('keywords.select_section')); ?></label>
                            <select class="form-control" name="section_id" id="section_id_edit">
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('keywords.upload_icon')); ?></label>
                            <div class="d-flex align-items-center">
                                <label class="btn btn-outline-success me-3" for="icon_edit">
                                    <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_icon')); ?>

                                </label>
                                <input type="file" name="icon" id="icon_edit" class="d-none" accept="image/*" onchange="previewEditIcon(event)">
                            </div>
                            <div class="mt-3">
                                <img id="icon_preview_edit" src="https://via.placeholder.com/150" alt="Icon Preview" class="img-thumbnail d-none" style="width: 50px; height: 50px;">
                            </div>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-warning"><?php echo e(__('keywords.save_changes')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openEditCategoryModal(button) {
            const categoryId = button.getAttribute('data-id');
            const categoryName = button.getAttribute('data-name');
            const sectionId = button.getAttribute('data-section-id');
            const iconUrl = button.getAttribute('data-icon');

            const form = document.getElementById('editCategoryForm');
            form.action = `/categories/update/${categoryId}`;

            document.getElementById('category_name_edit').value = categoryName;
            document.getElementById('section_id_edit').value = sectionId;

            const iconPreview = document.getElementById('icon_preview_edit');
            iconPreview.src = iconUrl;
            iconPreview.classList.remove('d-none');
        }

        function previewEditIcon(event) {
            const preview = document.getElementById('icon_preview_edit');
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = () => {
                    preview.src = reader.result;
                    preview.classList.remove('d-none');
                };
                reader.readAsDataURL(file);
            }
        }

        function previewNewIcon(event) {
            const preview = document.getElementById('icon_preview_new');
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = () => {
                    preview.src = reader.result;
                    preview.classList.remove('d-none');
                };
                reader.readAsDataURL(file);
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/categories/create.blade.php ENDPATH**/ ?>