<?php $__env->startSection('title', __('keywords.ads')); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <h2 class="h5 page-title"><?php echo e(__('keywords.filter_ads')); ?></h2>

                <!-- Filter Ads Modal Trigger -->
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#filterAdsModal">
                        <i class="fas fa-filter"></i> <?php echo e(__('keywords.filter_ads')); ?>

                    </button>
                </div>

                <!-- Filter Ads Modal -->
                <div class="modal fade" id="filterAdsModal" tabindex="-1" aria-labelledby="filterAdsModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title" id="filterAdsModalLabel"><?php echo e(__('keywords.filter_ads')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.ads.filter')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <!-- Section Dropdown -->
                                    <div class="mb-3">
                                        <label for="filter_section_id" class="form-label"><?php echo e(__('keywords.select_section')); ?></label>
                                        <select class="form-control" name="section_id" id="filter_section_id" required>
                                            <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                    </div>

                                    <!-- Category Dropdown -->
                                    <div class="mb-3">
                                        <label for="filter_category_id" class="form-label"><?php echo e(__('keywords.select_category')); ?></label>
                                        <select class="form-control" name="category_id" id="filter_category_id" required>
                                            <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                            <!-- Categories populated via JavaScript -->
                                        </select>
                                        <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                    </div>

                                    <!-- Member Dropdown -->
                                    <div class="mb-3">
                                        <label for="filter_member_id" class="form-label"><?php echo e(__('keywords.select_member')); ?></label>
                                        <select class="form-control" name="member_id" id="filter_member_id" required>
                                            <option value=""><?php echo e(__('keywords.select_member')); ?></option>
                                            <!-- Members populated via JavaScript -->
                                        </select>
                                        <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'member_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'member_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                    </div>

                                    <div class="d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('keywords.filter')); ?></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Display All Ads -->
                <div class="card mt-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h3 class="card-title mb-0"><?php echo e(__('keywords.ads')); ?></h3>
                        <div class="card-actions">
                            <!-- Add Ad Modal Trigger Button -->
                            <button class="btn btn-icon btn-outline-success" data-bs-toggle="modal" data-bs-target="#addAdModal">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered card-table table-vcenter text-nowrap datatable"  style="font-size: 12px;">
                                <thead class="thead-dark">
                                <tr>
                                    <th class="text-center"><?php echo e(__('keywords.ad_title')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.image')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.member')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.discount')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.status')); ?></th>
                                    <th class="text-center"><?php echo e(__('keywords.actions')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <!-- Ad Title -->
                                        <td class="text-center"><?php echo e($ad->title); ?></td>

                                        <!-- Ad Icon -->
                                        <td class="text-center">
                                            <img src="<?php echo e("/". $ad->image); ?>" alt="Ad Icon" style="width: 40px; height: 40px;" class="rounded">
                                        </td>

                                        <!-- Member Name -->
                                        <td class="text-center"><?php echo e($ad->member->name ?? __('keywords.unknown_member')); ?></td>

                                        <!-- Discount -->
                                        <td class="text-center"><?php echo e($ad->discount ?? 0); ?>%</td>
                                        <!-- type -->
                                        <td class="text-center"><?php echo e($ad->status); ?></td>

                                        <!-- Actions -->
                                        <td class="text-center">
                                            <!-- Show Ad Button -->
                                            <a href="<?php echo e(route('admin.ads.show', $ad->id)); ?>" class="btn btn-info btn-sm me-2" title="<?php echo e(__('keywords.show')); ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <!-- Edit Ad Button -->
                                            <a href="#" class="btn btn-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#editAdModal-<?php echo e($ad->id); ?>" title="<?php echo e(__('keywords.edit')); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <!-- Edit Ad Modal -->
                                            <div class="modal fade" id="editAdModal-<?php echo e($ad->id); ?>" tabindex="-1" aria-labelledby="editAdModalLabel-<?php echo e($ad->id); ?>" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header bg-warning text-white">
                                                            <h5 class="modal-title" id="editAdModalLabel-<?php echo e($ad->id); ?>"><?php echo e(__('keywords.edit_ad')); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('admin.ads.edit', $ad->id)); ?>" method="post" enctype="multipart/form-data" class="row g-3">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>

                                                                <!-- Section and Category Selection -->
                                                                <div class="col-md-6">
                                                                    <label for="section_id_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_section')); ?></label>
                                                                    <select class="form-control" name="section_id" id="section_id_edit_<?php echo e($ad->id); ?>" data-ad-id="<?php echo e($ad->id); ?>" required>
                                                                        <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($section->id); ?>" <?php echo e($ad->member->category->section_id == $section->id ? 'selected' : ''); ?>>
                                                                                <?php echo e($section->name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="category_id_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_category')); ?></label>
                                                                    <select class="form-control" name="category_id" id="category_id_edit_<?php echo e($ad->id); ?>" required>
                                                                        <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                                                        <?php $__currentLoopData = \App\Models\Category::where('section_id', $ad->member->category->section_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($category->id); ?>" <?php echo e($ad->member->category_id == $category->id ? 'selected' : ''); ?>>
                                                                                <?php echo e($category->name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <!-- Categories will be populated via JavaScript -->
                                                                    </select>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <!-- Member Selection and Status -->
                                                                <div class="col-md-6">
                                                                    <label for="member_id_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_member')); ?></label>
                                                                    <select class="form-control" name="member_id" id="member_id_edit_<?php echo e($ad->id); ?>" required>
                                                                        <option value=""><?php echo e(__('keywords.select_member')); ?></option>
                                                                        <?php $__currentLoopData = \App\Models\member::where('category_id', $ad->member->category_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($member->id); ?>" <?php echo e($ad->member_id == $member->id ? 'selected' : ''); ?>>
                                                                                <?php echo e($member->name); ?>

                                                                            </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <!-- Members will be populated via JavaScript -->
                                                                    </select>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'member_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'member_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="status_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.select_status')); ?></label>
                                                                    <select class="form-control" name="status" id="status_edit_<?php echo e($ad->id); ?>" required>
                                                                        <option value="normal" <?php echo e($ad->status == 'normal' ? 'selected' : ''); ?>><?php echo e(__('keywords.ad_normal')); ?></option>
                                                                        <option value="top" <?php echo e($ad->status == 'top' ? 'selected' : ''); ?>><?php echo e(__('keywords.ad_top')); ?></option>
                                                                    </select>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'status']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <!-- Ad Title and Discount -->
                                                                <div class="col-md-6">
                                                                    <label for="ad_title_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.ad_title')); ?></label>
                                                                    <input type="text" name="title" id="ad_title_edit_<?php echo e($ad->id); ?>" class="form-control" value="<?php echo e($ad->title); ?>" placeholder="<?php echo e(__('keywords.enter_ad_title')); ?>" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'title']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <label for="discount_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.discount')); ?></label>
                                                                    <input type="number" name="discount" id="discount_edit_<?php echo e($ad->id); ?>" class="form-control" value="<?php echo e($ad->discount); ?>" placeholder="<?php echo e(__('keywords.enter_discount')); ?>" min="0" max="100" required>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'discount']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'discount']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <!-- Ad Description -->
                                                                <div class="col-md-12">
                                                                    <label for="ad_description_edit_<?php echo e($ad->id); ?>" class="form-label fw-bold"><?php echo e(__('keywords.ad_description')); ?></label>
                                                                    <textarea name="description" id="ad_description_edit_<?php echo e($ad->id); ?>" class="form-control" placeholder="<?php echo e(__('keywords.enter_ad_description')); ?>" rows="3" required><?php echo e($ad->description); ?></textarea>
                                                                    <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'description']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                                                                </div>

                                                                <!-- Image Upload Field with Preview for Edit Modal -->
                                                                <div class="col-md-6">
                                                                    <label class="form-label fw-bold"><?php echo e(__('keywords.upload_image')); ?></label>
                                                                    <div class="d-flex align-items-center">
                                                                        <label class="btn btn-outline-warning me-3" for="image_upload_edit_<?php echo e($ad->id); ?>">
                                                                            <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_image')); ?>

                                                                        </label>
                                                                        <input type="file" name="image_upload" id="image_upload_edit_<?php echo e($ad->id); ?>" class="d-none" accept="image/*" onchange="previewImage(event, 'image_preview_edit_<?php echo e($ad->id); ?>')" >
                                                                    </div>
                                                                    <div class="mt-3">
                                                                        <img id="image_preview_edit_<?php echo e($ad->id); ?>" src="<?php echo e($ad->image ? asset($ad->image) : 'https://via.placeholder.com/150'); ?>"
                                                                             alt="Image Preview" class="img-thumbnail" style="max-width: 100%; height: auto;">
                                                                    </div>
                                                                </div>

                                                                <!-- Submit Button -->
                                                                <div class="col-12 d-flex justify-content-end">
                                                                    <button type="submit" class="btn btn-warning"><?php echo e(__('keywords.save_changes')); ?></button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Delete Ad Button -->
                                            <form action="<?php echo e(route('admin.ads.destroy', $ad->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('keywords.confirm_delete')); ?>')" title="<?php echo e(__('keywords.delete')); ?>">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- End of Ads List -->

            </div>
        </div>
    </div>

    <!-- Add Ad Modal -->
    <div class="modal fade" id="addAdModal" tabindex="-1" aria-labelledby="addAdModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="addAdModalLabel"><?php echo e(__('keywords.add_new_ad')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.ads.store')); ?>" method="post" enctype="multipart/form-data" class="row g-3">
                        <?php echo csrf_field(); ?>

                        <!-- Section and Category Selection -->
                        <div class="col-md-6">
                            <label for="section_id" class="form-label fw-bold"><?php echo e(__('keywords.select_section')); ?></label>
                            <select class="form-control" name="section_id" id="section_id" required>
                                <option value=""><?php echo e(__('keywords.select_section')); ?></option>
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'section_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'section_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <div class="col-md-6">
                            <label for="category_id" class="form-label fw-bold"><?php echo e(__('keywords.select_category')); ?></label>
                            <select class="form-control" name="category_id" id="category_id_2" required>
                                <option value=""><?php echo e(__('keywords.select_category')); ?></option>
                                <!-- Categories populated via JavaScript -->
                            </select>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'category_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'category_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <!-- Member Selection and Status -->
                        <div class="col-md-6">
                            <label for="member_id" class="form-label fw-bold"><?php echo e(__('keywords.select_member')); ?></label>
                            <select class="form-control" name="member_id" id="member_id_2" required>
                                <option value=""><?php echo e(__('keywords.select_member')); ?></option>
                                <!-- Members populated via JavaScript -->
                            </select>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'member_id']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'member_id']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <div class="col-md-6">
                            <label for="status" class="form-label fw-bold"><?php echo e(__('keywords.select_status')); ?></label>
                            <select class="form-control" name="status" id="status" required>
                                <option value="normal"><?php echo e(__('keywords.ad_normal')); ?></option>
                                <option value="top"><?php echo e(__('keywords.ad_top')); ?></option>
                            </select>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'status']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <!-- Ad Title and Discount -->
                        <div class="col-md-6">
                            <label for="ad_title" class="form-label fw-bold"><?php echo e(__('keywords.ad_title')); ?></label>
                            <input type="text" name="title" id="ad_title" class="form-control" placeholder="<?php echo e(__('keywords.enter_ad_title')); ?>" required>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'title']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'title']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <div class="col-md-6">
                            <label for="discount" class="form-label fw-bold"><?php echo e(__('keywords.discount')); ?></label>
                            <input type="number" name="discount" id="discount" class="form-control" placeholder="<?php echo e(__('keywords.enter_discount')); ?>" min="0" max="100" required>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'discount']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'discount']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <!-- Ad Description -->
                        <div class="col-md-12">
                            <label for="ad_description" class="form-label fw-bold"><?php echo e(__('keywords.ad_description')); ?></label>
                            <textarea name="description" id="ad_description" class="form-control" placeholder="<?php echo e(__('keywords.enter_ad_description')); ?>" rows="3" required></textarea>
                            <?php if (isset($component)) { $__componentOriginal594183d37f8c049899e337756ec33e4f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal594183d37f8c049899e337756ec33e4f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-error','data' => ['field' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('validation-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => 'description']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $attributes = $__attributesOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__attributesOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal594183d37f8c049899e337756ec33e4f)): ?>
<?php $component = $__componentOriginal594183d37f8c049899e337756ec33e4f; ?>
<?php unset($__componentOriginal594183d37f8c049899e337756ec33e4f); ?>
<?php endif; ?>
                        </div>

                        <!-- Image Upload Field with Preview for Add Modal -->
                        <div class="col-md-6">
                            <label class="form-label fw-bold"><?php echo e(__('keywords.upload_image')); ?></label>
                            <div class="d-flex align-items-center">
                                <label class="btn btn-outline-success me-3" for="image_upload">
                                    <i class="bi bi-upload me-2"></i> <?php echo e(__('keywords.choose_image')); ?>

                                </label>
                                <input type="file" name="image_upload" id="image_upload" class="d-none" accept="image/*" onchange="previewImage(event, 'image_preview')" required>
                            </div>
                            <div class="mt-3">
                                <img id="image_preview" src="https://via.placeholder.com/150" alt="Image Preview" class="img-thumbnail d-none" style="max-width: 100%; height: auto;" required>
                            </div>
                        </div>


                        <!-- Submit Button -->
                        <div class="col-12 d-flex justify-content-end">
                            <button type="submit" class="btn btn-success"><?php echo e(__('keywords.add_ad')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    // Preview image function for dynamic previews
    function previewImage(event, previewId) {
        const preview = document.getElementById(previewId);
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                preview.src = reader.result;
                preview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Helper function to populate category dropdown based on section
        function setupCategoryDropdown(sectionDropdown, categoryDropdown) {
            sectionDropdown.addEventListener('change', function () {
                const sectionId = this.value;

                // Clear existing options
                categoryDropdown.innerHTML = `<option value=""><?php echo e(__('keywords.select_category')); ?></option>`;

                if (sectionId) {
                    fetch(`/categories/${sectionId}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(category => {
                                const option = document.createElement('option');
                                option.value = category.id;
                                option.textContent = category.name;
                                categoryDropdown.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Error fetching categories:', error));
                }
            });
        }

        // Helper function to populate member dropdown based on category
        function setupMemberDropdown(categoryDropdown, memberDropdown) {
            categoryDropdown.addEventListener('change', function () {
                const categoryId = this.value;

                // Clear existing options
                memberDropdown.innerHTML = `<option value=""><?php echo e(__('keywords.select_member')); ?></option>`;

                if (categoryId) {
                    fetch(`/members/${categoryId}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(member => {
                                const option = document.createElement('option');
                                option.value = member.id;
                                option.textContent = member.name;
                                memberDropdown.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Error fetching members:', error));
                }
            });
        }

        // Setup for Filter Modal
        const filterSectionDropdown = document.getElementById('filter_section_id');
        const filterCategoryDropdown = document.getElementById('filter_category_id');
        const filterMemberDropdown = document.getElementById('filter_member_id');
        if (filterSectionDropdown && filterCategoryDropdown) {
            setupCategoryDropdown(filterSectionDropdown, filterCategoryDropdown);
        }
        if (filterCategoryDropdown && filterMemberDropdown) {
            setupMemberDropdown(filterCategoryDropdown, filterMemberDropdown);
        }

        // Setup for Add Modal
        const addSectionDropdown = document.getElementById('section_id');
        const addCategoryDropdown = document.getElementById('category_id_2');
        const addMemberDropdown = document.getElementById('member_id_2');
        if (addSectionDropdown && addCategoryDropdown) {
            setupCategoryDropdown(addSectionDropdown, addCategoryDropdown);
        }
        if (addCategoryDropdown && addMemberDropdown) {
            setupMemberDropdown(addCategoryDropdown, addMemberDropdown);
        }

        // Setup for Edit Modals
        document.querySelectorAll('[id^="section_id_edit_"]').forEach(sectionDropdown => {
            const memberId = sectionDropdown.id.replace('section_id_edit_', '');
            const categoryDropdown = document.getElementById(`category_id_edit_${memberId}`);
            const memberDropdown = document.getElementById(`member_id_edit_${memberId}`);

            if (categoryDropdown) {
                setupCategoryDropdown(sectionDropdown, categoryDropdown);
            }
            if (categoryDropdown && memberDropdown) {
                setupMemberDropdown(categoryDropdown, memberDropdown);
            }
        });
    });
</script>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msarweb-a1/htdocs/a1.msarweb.net/resources/views/admin/ads/create.blade.php ENDPATH**/ ?>